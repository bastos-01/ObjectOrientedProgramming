package aula08;

public enum TipoPeixe {
	CONGELADO, FRESCO
}
